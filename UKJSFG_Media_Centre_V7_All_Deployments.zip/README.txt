UKJSFG MEDIA CENTRE — HOME BASE + OPERATIONS ARCHIVE
====================================================

READY-TO-UPLOAD FILES (for your existing UKJSFG GitHub Pages repository)

- media.html        New Media Centre page
- media.css         Matching charcoal/olive design
- media-data.js     16 Home Base images + five confirmed operations
- media.js          Home Base filters, operation search, expandable dossiers, photo viewer
- assets/media/home-base/   16 optimised images from your uploads

HOW TO ADD TO GITHUB
1. Extract this ZIP on your PC.
2. Open https://github.com/UKJSFGhmsd1234/UKJSFG
3. On the main branch, select Add file > Upload files.
4. Drag the contents of this extracted folder into the upload area,
   preserving the assets/media/home-base/ subfolders.
5. Commit the files.
6. In index.html find the existing menu link:
   <a href="#media">MEDIA</a>
   Replace it with:
   <a href="media.html">MEDIA</a>
   Then commit the edit.
7. Your new Media page should be at https://ukjsfg.co.uk/media.html

IMPORTANT
- No existing website files are overwritten by this package.
- The current homepage's old #media section remains intact for now.
- The five operations are named but have no invented dates, missions or images.
- To add future deployments, edit media-data.js and add another object to
  the operations array. Add genuine operation images under assets/media/operations/
  and list their paths in that operation's images array.
- The Home Base gallery is populated with your sixteen uploaded images.
- Some uploads are collages of multiple screenshots; they are preserved as collages.

If GitHub won't preserve folders during drag-and-drop, upload the assets
using GitHub's web editor within the target folders or a desktop Git client.

V4 ADDITION: Operation Crimson Horizon (Bosnia) now has 20 genuine uploaded screenshots and a cover image. All five operation entries remain in the data file; future operation folders can be added easily.

V5 ADDITION: Two further Bosnia screenshots added (indoor team response and industrial building scene). A repeated Home Base personnel photo was recognised and skipped. Totals: 16 Home Base + 20 Bosnia = 36 unique gallery images.

V6 ADDITION: Afghanistan / Operation Desert Fury now has 6 supplied images and a cover.
Also added the 7 previously supplied unique Egypt / Operation Sandstorm images that were
not yet included in V5. Duplicate Egypt screenshots were excluded.
Total: 16 Home Base + 20 Bosnia + 7 Egypt + 6 Afghanistan = 49 images.
Goglands / Iron Viper and Ukraine Defence / Iron Shield remain available for future media.
This ZIP contains no changes to your live website or existing index.html.

V7 ADDITION: Goglands / Operation Iron Viper has ten supplied screenshots.
CORRECTION: Bosnia photos 11-20 in prior versions were Ukraine Defence photos; all ten moved to Operation Iron Shield.
TOTAL: 16 Home Base + 10 Bosnia + 6 Afghanistan + 7 Egypt + 10 Ukraine Defence + 10 Goglands = 59 unique images.
All five deployment galleries now populated. No live website changes.
